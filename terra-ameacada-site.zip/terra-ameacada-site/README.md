# Terra Ameaçada — Arquivo da História

Site estático responsivo sobre o universo de **Terra Ameaçada**, limitado aos episódios 1 e 2.

## Arquivos
- `index.html`: páginas e textos da história.
- `styles.css`: aparência do site.
- `characters.js`: nomes, nicks das skins, status e biografias.
- `app.js`: busca, filtros, pop-up de personagens e exibição das skins.

## Atualizar skins e personagens
Abra `characters.js` e altere `skin: null` para `skin: 'NickNoMinecraft'`. Para acrescentar personagem, duplique um item do array e preencha os campos. Para status, use `'vivo'` ou `'morto'`.

As skins são consultadas em https://mc-heads.net/player/NICK/250. Precisam de conexão com internet; os personagens sem nick usam um avatar genérico.

## Publicar pelo celular
1. Descompacte o ZIP no app **Arquivos** do iPhone.
2. Acesse github.com pelo Safari e crie um repositório novo, por exemplo `terra-ameacada`.
3. Use **Add file → Upload files** no repositório e envie `index.html`, `styles.css`, `characters.js`, `app.js` (todos na raiz). Em telas pequenas, pode ser necessário solicitar 'Site para Computador' pelo Safari.
4. Acesse vercel.com, faça login com GitHub, clique **Add New → Project**, importe o repositório e faça **Deploy**.
5. A Vercel criará um domínio `nome-do-projeto.vercel.app` se disponível.

Não é necessário instalar Node.js nem programar no celular. O projeto é HTML/CSS/JS puro, com configuração automática de framework 'Other' na Vercel.

## Observação editorial
Este arquivo é uma versão inicial do lore, baseada nas informações já confirmadas até o EP2. Revise eventos e adicione personagens faltantes antes da divulgação pública.
